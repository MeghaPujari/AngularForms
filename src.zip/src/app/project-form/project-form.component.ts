import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Project } from '../model/project';
import { ServiceService } from '../service.service';
import { ValidateProjectName } from '../customvalidator.validator';

@Component({
  selector: 'app-project-form',
  templateUrl: './project-form.component.html',
  styleUrls: ['./project-form.component.css']
})
export class ProjectFormComponent implements OnInit {
  constructor(private fb:FormBuilder,private cs:ServiceService) { }
  subscriptions: any = ['Stable', 'Critical', 'Finished'];

  project!:Project[]
  
  projectForm!:FormGroup;

  emailpattern!:"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  

  ngOnInit(): void {

    
    this.projectForm=this.fb.group({
     
      email:['',[Validators.required,Validators.pattern(this.emailpattern)]],
      projectName:['',[Validators.required,ValidateProjectName]],
      projectStatus:['',[Validators.required]]
    })
  }

   onSubmit()
  {
    console.log("submit");
  if(this.projectForm.valid)
    {
      console.log("valid");
    this.cs.ProjectSave(this.projectForm.value).subscribe();
    console.log("Form Values" + JSON.stringify(this.projectForm.value));
    // window.location.reload();
    }  
  } 
}

