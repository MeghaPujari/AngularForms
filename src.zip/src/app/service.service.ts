import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';
import { SubsForm } from './model/subs-form';
import { Project } from './model/project';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(public http:HttpClient) { }
  url:string="http://localhost:60114";
  
  SubsSave(subs:SubsForm)
  {
      return this.http.post<SubsForm>(this.url+"/save",subs);
  }
  ProjectSave(project:Project)
  {
      return this.http.post<Project>(this.url+"/save",project);
  }

}
