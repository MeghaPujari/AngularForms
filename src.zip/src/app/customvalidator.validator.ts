import {AbstractControl, ValidationErrors, ValidatorFn} from '@angular/forms';

// To validate 
export function ValidateProjectName(control:AbstractControl)  {
        
    if (control.value == "test") {
        console.log(control.value)
      return { InvalidPName: true };
    }
    return null;
  }
