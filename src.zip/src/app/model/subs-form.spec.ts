import { SubsForm } from './subs-form';

describe('SubsForm', () => {
  it('should create an instance', () => {
    expect(new SubsForm()).toBeTruthy();
  });
});
