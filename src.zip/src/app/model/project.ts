export class Project {
    projectName:string;
    projectStatus:string;
    mail:string
}
