export class SubsForm {
    mail:string;
    subscription:string;
    password:string
}
