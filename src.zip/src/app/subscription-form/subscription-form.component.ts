import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { SubsForm } from '../model/subs-form';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-subscription-form',
  templateUrl: './subscription-form.component.html',
  styleUrls: ['./subscription-form.component.css']
})
export class SubscriptionFormComponent implements OnInit {
  constructor(private fb:FormBuilder,private cs:ServiceService) { }
  subscriptions: any = ['Basic', 'Advanced', 'Pro'];

  subs!:SubsForm[]
  
  subsForm!:FormGroup;

  emailpattern!:"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  submitted = false;  
  email:string="";
  subscription:string="";
  password:string="";

  ngOnInit(): void {

    this.submitted = false;
    this.subsForm=this.fb.group({
     
      email:['',[Validators.required,Validators.pattern(this.emailpattern)]],
      subscription:['',[Validators.required]],
      password:['',[Validators.required]]
    })
  }

  onSubmit()
  {

    if(this.subsForm.valid)
    {
    this.submitted = true;
    
    this.cs.SubsSave(this.subsForm.value).subscribe();
    // window.location.reload();
    }
 }
}
