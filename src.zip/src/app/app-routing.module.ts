import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SubscriptionFormComponent } from './subscription-form/subscription-form.component';
import { ProjectFormComponent } from './project-form/project-form.component';

const routes: Routes = [


{path:"", component:HomeComponent},
{path:"subscription-form", component:SubscriptionFormComponent},
{path:"project-form", component:ProjectFormComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
